# /gui/reader_window.py
import tkinter as tk
from tkinter import ttk, messagebox, font, scrolledtext
from pathlib import Path
import os
import re
import copy
import threading
import queue
import logging
import time # Import time

logger = logging.getLogger(__name__)
##
VIETNAMESE_NUMBER_WORDS = {
    "không", "linh", "một", "mốt", "hai", "nhị", "ba", "tam", "bốn", "tư", "tứ",
    "năm", "lăm", "ngũ", "sáu", "lục", "bảy", "thất", "tám", "bát", "chín", "cửu",
    "mười", "mươi", "thập", "trăm", "bách", "nghìn", "ngàn", "thiên", "vạn",
    "triệu", "tỷ"
}
# Từ khóa bắt đầu chương
CHAPTER_KEYWORDS = {"chương", "quyển", "đệ", "c"}
# Từ đệm có thể có
BUFFER_WORDS = {"thứ"}
##

# ==============================================================
# LỚP CỬA SỔ XÁC NHẬN ĐƠN GIẢN
# ==============================================================
class ConfirmationDialog(tk.Toplevel):
    def __init__(self, parent, title, message):
        super().__init__(parent)
        self.title(title)
        self.result = False
        self.resizable(False, False)
        #self.transient(parent)
        #self.grab_set()

        content_frame = ttk.Frame(self, padding="10 10 10 10")
        content_frame.pack(expand=True, fill="both")
        ttk.Label(content_frame, text=message, wraplength=350, justify="left").pack(padx=10, pady=(0, 15))
        button_frame = ttk.Frame(content_frame)
        button_frame.pack(pady=5)
        yes_button = ttk.Button(button_frame, text="Đồng ý (Yes)", command=self.on_yes, width=12, bootstyle="success")
        yes_button.pack(side="left", padx=10)
        no_button = ttk.Button(button_frame, text="Hủy bỏ (No)", command=self.on_no, width=12, bootstyle="secondary")
        no_button.pack(side="left", padx=10)

        self.update_idletasks()
        parent_x = parent.winfo_rootx(); parent_y = parent.winfo_rooty()
        parent_width = parent.winfo_width(); parent_height = parent.winfo_height()
        dialog_width = self.winfo_width(); dialog_height = self.winfo_height()
        x = parent_x + (parent_width // 2) - (dialog_width // 2)
        y = parent_y + (parent_height // 2) - (dialog_height // 2)
        self.geometry(f'+{x}+{y}')
        self.wait_window(self)

    def on_yes(self): self.result = True; self.destroy()
    def on_no(self): self.result = False; self.destroy()

# ==============================================================
# LỚP CỬA SỔ XEM TRƯỚC CHUNG (CHO FIX/INSERT)
# ==============================================================
class PreviewWindow(tk.Toplevel):
    MAX_PREVIEW_ITEMS = 200
    def __init__(self, parent, window_title, preview_data, total_selected_count, apply_callback_func, apply_button_text="✅ Áp dụng"):
        super().__init__(parent)
        self.title(window_title)
        self.geometry("1200x750")
        #self.minsize(700, 450)
        #self.transient(parent)
        #self.grab_set()

        self.preview_data = preview_data
        self.total_selected_count = total_selected_count
        self.apply_callback = apply_callback_func
        self.apply_button_text = apply_button_text

        self.setup_ui()
        self.populate_treeview()

        self.update_idletasks()
        parent_x = parent.winfo_rootx(); parent_y = parent.winfo_rooty()
        parent_width = parent.winfo_width(); parent_height = parent.winfo_height()
        dialog_width = self.winfo_width(); dialog_height = self.winfo_height()
        x = parent_x + (parent_width // 2) - (dialog_width // 2)
        y = parent_y + (parent_height // 2) - (dialog_height // 2)
        self.geometry(f'+{x}+{y}')

    def setup_ui(self):
        self.info_label = ttk.Label(self, text="", bootstyle="warning")
        self.info_label.pack(pady=(5, 0), padx=10, anchor="w")
        tree_frame = ttk.Frame(self)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)
        tree_scroll = ttk.Scrollbar(tree_frame)
        tree_scroll.pack(side="right", fill="y")
        self.tree = ttk.Treeview(tree_frame, columns=("filename", "original", "proposed"), show="headings", yscrollcommand=tree_scroll.set, selectmode="none")
        tree_scroll.config(command=self.tree.yview)
        self.tree.heading("filename", text="Tên File")
        self.tree.heading("original", text="Dòng đầu gốc")
        self.tree.heading("proposed", text="Dòng đầu mới (Đề xuất)")
        self.tree.column("filename", anchor="w", width=200, stretch=tk.NO)
        self.tree.column("original", anchor="w", width=350)
        self.tree.column("proposed", anchor="w", width=350)
        self.tree.pack(fill="both", expand=True)
        button_frame = ttk.Frame(self)
        button_frame.pack(fill="x", padx=10, pady=(5, 10))
        ttk.Button(button_frame, text="Hủy bỏ", command=self.destroy, bootstyle="secondary").pack(side="right", padx=5)
        apply_count = len(self.preview_data)
        ttk.Button(button_frame, text=f"{self.apply_button_text} ({apply_count} file)", command=self.trigger_apply, bootstyle="success").pack(side="right", padx=5)

    def populate_treeview(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        items_to_display = self.preview_data[:self.MAX_PREVIEW_ITEMS]
        for item in items_to_display:
            orig_display = item.get('original_line', '')[:100] + ('...' if len(item.get('original_line', '')) > 100 else '')
            new_display_key = 'new_line' if 'new_line' in item else 'inserted_line'
            new_display = item.get(new_display_key, '')[:100] + ('...' if len(item.get(new_display_key, '')) > 100 else '')
            self.tree.insert("", tk.END, values=(item.get('filename', ''), orig_display, new_display))
        if len(self.preview_data) > self.MAX_PREVIEW_ITEMS: self.info_label.config(text=f"Lưu ý: Chỉ hiển thị {self.MAX_PREVIEW_ITEMS} / {len(self.preview_data)} mục sẽ áp dụng...")
        elif not self.preview_data: self.info_label.config(text="Không có thay đổi xem trước.")
        else: self.info_label.config(text="")

    def trigger_apply(self):
        confirm = messagebox.askyesno("Xác nhận cuối cùng", f"Áp dụng thay đổi cho {len(self.preview_data)} file?", parent=self)
        if confirm: self.apply_callback(self.preview_data); self.destroy()


# --- LỚP PREVIEW MỚI CHO VIỆC XÓA LẶP ---
class DuplicatePreviewWindow(tk.Toplevel):
    """Cửa sổ xem trước các dòng lặp sẽ bị xóa."""
    MAX_PREVIEW_ITEMS = 200
    def __init__(self, parent, window_title, preview_data, apply_callback_func):
        super().__init__(parent)
        self.title(window_title)
        self.geometry("950x550")
        self.minsize(700, 450)
        self.transient(parent)
        self.grab_set()

        self.preview_data = preview_data # List of dicts from show_duplicate_line_preview
        self.apply_callback = apply_callback_func

        self.setup_ui()
        self.populate_treeview()

        self.update_idletasks()
        parent_x=parent.winfo_rootx(); parent_y=parent.winfo_rooty(); parent_width=parent.winfo_width(); parent_height=parent.winfo_height(); dialog_width=self.winfo_width(); dialog_height=self.winfo_height(); x=parent_x+(parent_width//2)-(dialog_width//2); y=parent_y+(parent_height//2)-(dialog_height//2); self.geometry(f'+{x}+{y}')

    def setup_ui(self):
        self.info_label = ttk.Label(self, text="", bootstyle="warning")
        self.info_label.pack(pady=(5, 0), padx=10, anchor="w")

        tree_frame = ttk.Frame(self)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=5)
        tree_scroll = ttk.Scrollbar(tree_frame)
        tree_scroll.pack(side="right", fill="y")

        # Đổi tên cột cho phù hợp
        self.tree = ttk.Treeview(tree_frame, columns=("filename", "line_to_keep", "line_to_remove"), show="headings", yscrollcommand=tree_scroll.set, selectmode="none")
        tree_scroll.config(command=self.tree.yview)

        self.tree.heading("filename", text="Tên File")
        self.tree.heading("line_to_keep", text="Dòng đầu (Giữ lại)")
        self.tree.heading("line_to_remove", text="Dòng lặp (Sẽ xóa)") # Đổi tên heading

        self.tree.column("filename", anchor="w", width=200, stretch=tk.NO)
        self.tree.column("line_to_keep", anchor="w", width=350)
        self.tree.column("line_to_remove", anchor="w", width=350) # Đổi tên cột

        self.tree.pack(fill="both", expand=True)

        button_frame = ttk.Frame(self)
        button_frame.pack(fill="x", padx=10, pady=(5, 10))

        ttk.Button(button_frame, text="Hủy bỏ", command=self.destroy, bootstyle="secondary").pack(side="right", padx=5)
        apply_count = len(self.preview_data)
        # Đổi text nút áp dụng
        ttk.Button(button_frame, text=f"✅ Áp dụng xóa ({apply_count} file)", command=self.trigger_apply, bootstyle="danger").pack(side="right", padx=5) # Dùng bootstyle danger

    def populate_treeview(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        items_to_display = self.preview_data[:self.MAX_PREVIEW_ITEMS]
        for item in items_to_display:
            # Lấy đúng dữ liệu từ dict preview_data
            keep_display = item.get('original_line', '')[:100] + ('...' if len(item.get('original_line', '')) > 100 else '')
            remove_display = item.get('proposed', '')[:100] + ('...' if len(item.get('proposed', '')) > 100 else '') # 'proposed' holds the line to remove
            self.tree.insert("", tk.END, values=(item.get('filename', ''), keep_display, remove_display))

        if len(self.preview_data) > self.MAX_PREVIEW_ITEMS: self.info_label.config(text=f"Lưu ý: Chỉ hiển thị {self.MAX_PREVIEW_ITEMS} / {len(self.preview_data)} mục sẽ được xóa...")
        elif not self.preview_data: self.info_label.config(text="Không tìm thấy dòng lặp nào.")
        else: self.info_label.config(text="")

    def trigger_apply(self):
        confirm = messagebox.askyesno("Xác nhận cuối cùng", f"Áp dụng xóa các dòng lặp hiển thị cho {len(self.preview_data)} file?", parent=self)
        if confirm:
            # Truyền toàn bộ preview_data cho callback để xử lý
            self.apply_callback(self.preview_data)
            self.destroy()
# --- KẾT THÚC LỚP DuplicatePreviewWindow ---


# ==============================================================
# LỚP CỬA SỔ DANH SÁCH DÒNG ĐẦU
# ==============================================================
class FirstLinesWindow(tk.Toplevel):
    def __init__(self, parent, folder_path, reader_window_ref):
        super().__init__(parent)
        self.title("📋 Danh sách dòng đầu")
        self.geometry("950x650")
        self.minsize(750, 500)
        self.reader_window_ref = reader_window_ref # Reference to main reader
        self.base_folder_path = Path(folder_path)
        self.folder_path = self.base_folder_path / "translated" # Target the translated folder
        self.file_list = []
        self.all_items_data = [] # List of dictionaries: {'iid', 'filename', 'line', 'path', 'orig_filename', 'orig_line'}
        self.filter_after_id = None
        self.progress_queue = queue.Queue() # For thread communication

        logger.info(f"FirstLinesWindow: Initializing for folder {self.folder_path}")

        try:
            if not self.folder_path.is_dir(): raise FileNotFoundError(f"Thư mục không tồn tại: {self.folder_path}")
            self.file_list = sorted([f.name for f in self.folder_path.glob("*.txt") if f.is_file()])
            if not self.file_list: raise FileNotFoundError(f"Không tìm thấy file .txt trong: {self.folder_path}")
            logger.info(f"FirstLinesWindow: Found {len(self.file_list)} files.")
        except Exception as e:
            logger.error(f"FirstLinesWindow: Error reading directory: {e}", exc_info=True)
            messagebox.showerror("Lỗi đọc thư mục", f"{e}", parent=self)
            self.destroy(); return

        self.setup_ui()
        self._preload_data() # Load all data initially
        self._populate_treeview() # Populate the treeview with all data
        self.search_entry.focus_set()

    def setup_ui(self):
        # --- Filter Frame ---
        top_filter = ttk.Frame(self); top_filter.pack(fill="x", padx=10, pady=5)
        self.filter_type_var = tk.StringVar(value="Chứa"); filter_options = ["Chứa", "Bắt đầu bằng", "Không chứa"]
        self.filter_combo = ttk.Combobox(top_filter, textvariable=self.filter_type_var, values=filter_options, state="readonly", width=12); self.filter_combo.pack(side="left", padx=(0, 5))
        self.search_var = tk.StringVar(); self.search_entry = ttk.Entry(top_filter, textvariable=self.search_var, width=40); self.search_entry.pack(side="left", padx=5, fill="x", expand=True)
        self.hide_correct_var = tk.BooleanVar(value=False); self.hide_correct_cb = ttk.Checkbutton(top_filter, text="Ẩn file đúng định dạng", variable=self.hide_correct_var); self.hide_correct_cb.pack(side="left", padx=10)

        # --- Treeview Frame ---
        tree_frame = ttk.Frame(self); tree_frame.pack(fill="both", expand=True, padx=10, pady=(0, 5))
        tree_scroll_y = ttk.Scrollbar(tree_frame, orient="vertical"); tree_scroll_y.pack(side="right", fill="y")
        tree_scroll_x = ttk.Scrollbar(tree_frame, orient="horizontal"); tree_scroll_x.pack(side="bottom", fill="x")
        self.tree = ttk.Treeview(tree_frame, columns=("filename", "first_line"), show="headings", selectmode="extended", yscrollcommand=tree_scroll_y.set, xscrollcommand=tree_scroll_x.set)
        tree_scroll_y.config(command=self.tree.yview); tree_scroll_x.config(command=self.tree.xview)
        self.tree.heading("filename", text="Tên File", anchor='w'); self.tree.heading("first_line", text="Dòng đầu", anchor='w')
        self.tree.column("filename", anchor="w", width=250, stretch=tk.NO); self.tree.column("first_line", anchor="w", width=600)
        self.tree.pack(fill="both", expand=True)

        # --- Bindings ---
        self.search_var.trace_add("write", self._on_filter_change);
        self.filter_combo.bind("<<ComboboxSelected>>", self._on_filter_change);
        self.hide_correct_cb.config(command=self._on_filter_change);
        self.tree.bind("<Double-Button-1>", self._on_double_click) # Bind double-click

        # --- Action Buttons ---
        self.bottom_frame = ttk.Frame(self); self.bottom_frame.pack(fill="x", padx=10, pady=(5, 10))
        ttk.Button(self.bottom_frame, text="🔧 Fix số Chương", command=self.show_fix_preview).pack(side="left", padx=5)
        ttk.Button(self.bottom_frame, text="➕ Chèn số Chương", command=self.show_insert_preview).pack(side="left", padx=5)
        ttk.Button(self.bottom_frame, text="🧹 Xóa dòng đầu", command=self.trigger_delete_first_lines).pack(side="right", padx=5)

    def _preload_data(self):
        self.all_items_data.clear(); logger.info("FirstLinesWindow: Preloading...")
        for i, filename in enumerate(self.file_list):
            path = self.folder_path / filename; line = ""
            try:
                encodings_to_try = ['utf-8', 'cp1252', 'latin-1']; read_ok = False
                for enc in encodings_to_try:
                    try:
                        with path.open('r', encoding=enc) as f: line = f.readline().strip(); read_ok = True; break
                    except UnicodeDecodeError: pass
                    except FileNotFoundError: line = "[Lỗi: Không tìm thấy]"; logger.warning(f"Not found preload (inner): {path}"); read_ok = True; break
                    except Exception as read_err: line = f"[Lỗi đọc: {type(read_err).__name__}]"; logger.error(f"Err read line {filename} {enc}: {read_err}"); read_ok = True; break
                if not read_ok: line = "[Lỗi đọc encoding]"; logger.warning(f"Failed read {filename} encodings.")
            except Exception as e: line = f"[Lỗi: {type(e).__name__}]"; logger.error(f"Unexpected preload error {filename}: {e}", exc_info=True)
            self.all_items_data.append({'iid': i, 'filename': filename.lower(), 'line': line.lower(), 'path': path, 'orig_filename': filename, 'orig_line': line})
        logger.info(f"FirstLinesWindow: Preloaded {len(self.all_items_data)} items.")

    def _populate_treeview(self, items_to_display=None):
        logger.debug("FirstLinesWindow: Populating treeview...")
        try:
            self.tree.delete(*self.tree.get_children()); data_source = items_to_display if items_to_display is not None else self.all_items_data
            for item_data in data_source:
                display_line = item_data['orig_line'][:150] + ('...' if len(item_data['orig_line']) > 150 else '')
                self.tree.insert('', tk.END, iid=item_data['iid'], values=(item_data['orig_filename'], display_line))
            logger.debug(f"Populated treeview with {len(data_source)} items.")
        except Exception as e: logger.error(f"Error populate treeview: {e}", exc_info=True)

    def _apply_filter(self):
        """Filters the preloaded data based on UI controls and updates Treeview."""
        filter_type = self.filter_type_var.get()
        keyword_raw = self.search_var.get().strip() # Keyword gốc người dùng nhập
        keyword_lower = keyword_raw.lower() # Keyword chữ thường cho so sánh case-insensitive
        hide_correct = self.hide_correct_var.get()
        logger.debug(f"Apply Filter: Type={filter_type}, Keyword='{keyword_raw}', Hide={hide_correct}")

        filtered_data = []
        for item_data in self.all_items_data:
            # Lấy cả bản gốc và bản chữ thường
            filename_lower = item_data['filename']
            orig_filename = item_data['orig_filename']
            line_lower = item_data['line']
            orig_line = item_data['orig_line']

            # Keyword Filtering
            matches_keyword = False
            if not keyword_raw: # Nếu không có keyword thì luôn khớp
                matches_keyword = True
            else:
                # --- SỬA LOGIC LỌC "CHỨA" ---
                if filter_type == "Chứa":
                    # So sánh keyword gốc (raw) với dòng gốc (orig_line)
                    # Và so sánh keyword chữ thường với dòng chữ thường (để tìm chữ không phân biệt hoa/thường)
                    # Nếu keyword là ký tự đặc biệt, so sánh với bản gốc sẽ hoạt động đúng
                    #matches_keyword = (keyword_raw in orig_filename or keyword_raw in orig_line)
                    # Escape để '.' thành '\.', không phải wildcard
                    pattern = re.escape(keyword_raw)
                    matches_keyword = bool(
                        re.search(pattern, orig_line, flags=re.IGNORECASE)
                    )                    
                # ---------------------------------
                elif filter_type == "Bắt đầu bằng":
                    # Vẫn dùng chữ thường cho "Bắt đầu bằng" để không phân biệt hoa/thường
                    matches_keyword = (filename_lower.startswith(keyword_lower) or line_lower.startswith(keyword_lower))
                elif filter_type == "Không chứa":
                     # So sánh cả bản gốc và bản chữ thường để đảm bảo không chứa
                    matches_keyword = (keyword_raw not in orig_filename and keyword_raw not in orig_line)

            if not matches_keyword:
                continue # Bỏ qua nếu không khớp keyword

            # Hide Correct Formatting Filter (logic này giữ nguyên)
            if hide_correct:
                # ... (Giữ nguyên logic kiểm tra định dạng) ...
                try:
                    match_num_c = re.search(r'[Cc]([0-9]+)', orig_filename); match_num_chuong = re.search(r'[Cc]hương\s*([0-9]+)', orig_filename); expected_num = None
                    if match_num_c: expected_num = int(match_num_c.group(1))
                    elif match_num_chuong: expected_num = int(match_num_chuong.group(1))
                    if expected_num is not None: correct_pattern = re.compile(rf'^\s*[Cc]hương\s+{expected_num}\s*[:]?.*', re.IGNORECASE);
                    if correct_pattern.match(orig_line): continue
                except ValueError: logger.warning(f"Could not parse chapter num: {orig_filename}")
                except Exception as e: logger.error(f"Error check 'hide_correct' {orig_filename}: {e}")

            # If all filters passed, add to results
            filtered_data.append(item_data)

        self._populate_treeview(filtered_data)
        logger.debug(f"Filter done. Displaying {len(filtered_data)} items.")

    def _on_filter_change(self, *args):
        if self.filter_after_id: self.after_cancel(self.filter_after_id)
        is_immediate = False; delay = 300
        if args:
            if isinstance(args[0], tk.Event) and args[0].widget in (self.filter_combo, self.hide_correct_cb): is_immediate = True
            elif isinstance(args[0], str) and args[0] == str(self.hide_correct_var._name): is_immediate = True
        if is_immediate: delay = 0
        self.filter_after_id = self.after(delay, self._apply_filter)

    def _run_file_operation_in_thread(self, items_to_process, operation_func, progress_title, completion_message_func):
        """Runs a file operation function on selected items in a separate thread."""
        if not items_to_process: messagebox.showwarning("Chưa chọn", "Không có mục hợp lệ.", parent=self); return
        progress_win = tk.Toplevel(self); progress_win.title(progress_title); progress_win.geometry("350x120"); progress_win.transient(self); progress_win.grab_set(); progress_win.resizable(False, False)
        status_label = ttk.Label(progress_win, text="Đang chuẩn bị..."); status_label.pack(pady=10, padx=10, anchor='w')
        progress_bar = ttk.Progressbar(progress_win, length=330, mode='determinate', maximum=len(items_to_process)); progress_bar.pack(pady=5, padx=10)
        self.update_idletasks(); parent_x=self.winfo_rootx(); parent_y=self.winfo_rooty(); parent_width=self.winfo_width(); parent_height=self.winfo_height(); dialog_width=progress_win.winfo_width(); dialog_height=progress_win.winfo_height(); x=parent_x+(parent_width//2)-(dialog_width//2); y=parent_y+(parent_height//2)-(dialog_height//2); progress_win.geometry(f'+{x}+{y}')

        def worker():
            processed_count=0; error_count=0; skipped_count=0; changed_paths = set()
            for i, item_data in enumerate(items_to_process):
                path = item_data.get('path') # Use get for safety
                filename = item_data.get('orig_filename', path.name if path else 'N/A') # Use get and provide fallback

                # Check if path is valid before proceeding
                if not path or not isinstance(path, Path):
                    logger.error(f"Invalid path found in item data for worker: {item_data}")
                    error_count += 1
                    self.progress_queue.put({'type': 'progress', 'value': i + 1}) # Update progress even on error
                    continue # Skip this item

                self.progress_queue.put({'type': 'status', 'text': f"Xử lý: {filename}"})
                try:
                    result = operation_func(item_data) # Call the specific operation
                    if result == 'processed':
                        processed_count += 1
                        changed_paths.add(path)
                    elif result == 'skipped':
                        skipped_count += 1
                    elif result == 'error': # If operation function explicitly returns 'error'
                         error_count += 1
                # *** THÊM KHỐI EXCEPT Ở ĐÂY ***
                except Exception as e:
                    logger.error(f"Worker error processing {filename}: {e}", exc_info=True)
                    error_count += 1 # Count as error if the operation itself raises an exception
                # *******************************
                # Update progress regardless of outcome for this item
                self.progress_queue.put({'type': 'progress', 'value': i + 1})

            # Signal completion
            self.progress_queue.put({'type': 'completion', 'processed': processed_count, 'errors': error_count, 'skipped': skipped_count, 'changed_paths': changed_paths})

        def check_queue():
            # ... (Logic check_queue không đổi) ...
            try:
                while True:
                    msg = self.progress_queue.get_nowait()
                    if not progress_win.winfo_exists(): return # Check window validity
                    if msg['type'] == 'status': status_label.config(text=msg['text'])
                    elif msg['type'] == 'progress': progress_bar['value'] = msg['value']
                    elif msg['type'] == 'completion':
                        progress_win.destroy(); final_message = completion_message_func(msg['processed'], msg['errors'], msg['skipped']); messagebox.showinfo("Hoàn tất", final_message, parent=self)
                        self._trigger_main_reader_update(msg['changed_paths']); return
                    progress_win.update_idletasks() # Allow UI update
            except queue.Empty:
                if progress_win.winfo_exists():
                    self.after(100, check_queue) # Reschedule if window still open
            except Exception as qe:
                logger.error(f"Error progress queue: {qe}", exc_info=True);
                if progress_win.winfo_exists(): progress_win.destroy()

        threading.Thread(target=worker, daemon=True).start()
        self.after(100, check_queue)

    def _update_treeview_item(self, iid, new_first_line):
        try:
            item_values = list(self.tree.item(iid, 'values'))
            if item_values:
                display_line = new_first_line[:150] + ('...' if len(new_first_line) > 150 else '')
                item_values[1] = display_line; self.tree.item(iid, values=tuple(item_values))
        except tk.TclError: logger.warning(f"Item iid={iid} not found update.")
        except Exception as e: logger.error(f"Error update treeview iid={iid}: {e}")

    def _get_selected_data(self):
        selected_iids_str = self.tree.selection(); selected_data = []
        for iid_str in selected_iids_str:
            try:
                iid_int = int(iid_str)
                found_item = next((item for item in self.all_items_data if item['iid'] == iid_int), None)
                if found_item: selected_data.append(found_item)
                else: logger.warning(f"Invalid iid {iid_int} selection.")
            except ValueError: logger.warning(f"Invalid iid '{iid_str}'.")
        logger.debug(f"Found {len(selected_data)} selected items."); return selected_data

    def _process_delete_first_line(self, item_data):
        path = item_data['path']; iid = item_data['iid']
        try:
            current_content = None; encodings = ['utf-8', 'cp1252', 'latin-1']; read_ok = False
            for enc in encodings:
                try:
                    current_content = path.read_text(encoding=enc)
                    read_ok = True
                    break
                except UnicodeDecodeError: pass
            if not read_ok or current_content is None: raise IOError("Could not read file")
            lines = current_content.splitlines(); new_content = ""
            if lines:
                first_non_blank_index = -1
                for idx in range(1, len(lines)):
                    if lines[idx].strip():
                        first_non_blank_index = idx
                        break
                if first_non_blank_index != -1: new_content = "\n".join(lines[first_non_blank_index:])
                if new_content != current_content:
                    path.write_text(new_content, encoding="utf-8"); new_first_line_display = lines[first_non_blank_index] if first_non_blank_index != -1 else ""
                    self.all_items_data[iid]['orig_line'] = new_first_line_display; self.all_items_data[iid]['line'] = new_first_line_display.lower()
                    self.after(0, lambda i=iid, n=new_first_line_display: self._update_treeview_item(i, n)); return 'processed'
                else: return 'skipped'
            else: return 'skipped'
        except FileNotFoundError: logger.error(f"Not found delete: {path.name}"); return 'error'
        except Exception as e: logger.error(f"Error delete line {path.name}: {e}", exc_info=True); return 'error'

    def _process_apply_fix(self, item_data):
        path = item_data['path']; new_first_line = item_data['new_line']; iid = item_data['iid']
        try:
            current_content = None; encodings = ['utf-8', 'cp1252', 'latin-1']; read_ok = False
            for enc in encodings:
                try:
                    current_content = path.read_text(encoding=enc); read_ok = True
                    break
                except UnicodeDecodeError: pass
            if not read_ok or current_content is None: raise IOError("Could not read file")
            lines = current_content.splitlines()
            if not lines: logger.warning(f"Empty file fix: {path.name}"); return 'error'
            original_first_line = lines[0]; lines[0] = new_first_line; new_content = "\n".join(lines)
            if new_content != current_content:
                path.write_text(new_content, encoding="utf-8"); self.all_items_data[iid]['orig_line'] = new_first_line; self.all_items_data[iid]['line'] = new_first_line.lower()
                self.after(0, lambda i=iid, n=new_first_line: self._update_treeview_item(i, n)); return 'processed'
            else: logger.debug(f"Skip fix {path.name}: no change."); return 'skipped'
        except FileNotFoundError: logger.error(f"Not found fix: {path.name}"); return 'error'
        except Exception as e: logger.error(f"Error apply fix {path.name}: {e}", exc_info=True); return 'error'

    def _process_insert_number(self, item_data):
        path = item_data['path']; filename = item_data['orig_filename']; iid = item_data['iid']
        try:
            match_num_c = re.search(r'[Cc]([0-9]+)', filename); match_num_chuong = re.search(r'[Cc]hương\s*([0-9]+)', filename); extracted_number = None
            if match_num_c: extracted_number = int(match_num_c.group(1))
            elif match_num_chuong: extracted_number = int(match_num_chuong.group(1))
            if extracted_number is None: logger.warning(f"No num insert: {filename}"); return 'error'
            current_content = None; encodings = ['utf-8', 'cp1252', 'latin-1']; read_ok = False
            for enc in encodings:
                try:
                    current_content = path.read_text(encoding=enc)
                    read_ok = True
                    break
                except UnicodeDecodeError: pass
            if not read_ok: raise IOError("Could not read")
            original_first_line = current_content.splitlines()[0].strip() if current_content and current_content.splitlines() else ""
            chapter_pattern = re.compile(r'^\s*[Cc]hương\s+\d+\s*[:]?.*', re.IGNORECASE)
            if chapter_pattern.match(original_first_line): logger.debug(f"Skip insert {filename}: formatted."); return 'skipped'
            prefix = f"Chương {extracted_number}: "; new_content = prefix + "\n\n" + (current_content if current_content is not None else "")
            if new_content != current_content:
                 path.write_text(new_content, encoding="utf-8"); new_display_first_line = prefix.strip()
                 self.all_items_data[iid]['orig_line'] = new_display_first_line; self.all_items_data[iid]['line'] = new_display_first_line.lower()
                 self.after(0, lambda i=iid, n=new_display_first_line: self._update_treeview_item(i, n)); return 'processed'
            else: return 'skipped'
        except FileNotFoundError: logger.error(f"Not found insert: {filename}"); return 'error'
        except ValueError: logger.error(f"Invalid num insert: {filename}"); return 'error'
        except Exception as e: logger.error(f"Error insert num {filename}: {e}", exc_info=True); return 'error'

    def trigger_delete_first_lines(self):
        logger.debug("Trigger delete first lines..."); selected_data = self._get_selected_data()
        if not selected_data: messagebox.showwarning("Chưa chọn", "Chọn ít nhất một file.", parent=self); return
        dialog = ConfirmationDialog(self, "Xác nhận xóa", f"Xóa dòng đầu của {len(selected_data)} file đã chọn?");
        if dialog.result: logger.info(f"Start delete first line {len(selected_data)} files."); msg = lambda p, e, s: f"Đã xóa dòng đầu {p} file.\nBỏ qua: {s} file.\nLỗi: {e} file."; self._run_file_operation_in_thread(selected_data, self._process_delete_first_line, "Đang xóa dòng đầu...", msg)
        else: logger.info("Delete first line cancelled.")

    def show_fix_preview(self):
        """
        Calculates and shows the preview for fixing chapter numbers.
        Logic v11: Prioritize explicit separators, then try word patterns.
        """
        logger.debug("Showing fix chapter number preview (Logic v11 - Priority Separator)...")
        selected_data = self._get_selected_data()
        total_selected = len(selected_data)
        if not selected_data: messagebox.showwarning("Chưa chọn", "Chọn ít nhất một file.", parent=self); return

        preview_items = []; errors_calculating = 0; skipped_count = 0
        filename_num_pattern = re.compile(r'[Cc](?:hương|ương)?\s*([0-9]+)') # Regex lấy số từ filename

        # Regex để khớp các từ khóa chương ở đầu
        chapter_keyword_pattern = re.compile(r'^\s*(?:[Qq]uyển|[Cc]hương|[Đđ]ệ|[Cc]|Hồi)\s*(?:thứ)?\s*', re.IGNORECASE)

        separators_to_try = [':', '.', ',', '-'] # Ưu tiên theo thứ tự này

        for item_data in selected_data:
            path = item_data['path']; filename = item_data['orig_filename']
            original_first_line = item_data['orig_line']; iid = item_data['iid']
            new_first_line = None; extracted_number_file = None; existing_title = ""
            processed = False

            try:
                # 1. Extract number from filename (Highest priority)
                match_filename = filename_num_pattern.search(filename)
                if match_filename:
                    try: extracted_number_file = int(match_filename.group(1))
                    except ValueError: pass
                if extracted_number_file is None:
                    logger.debug(f"Skip fix {filename}: No num filename.")
                    skipped_count += 1; continue

                # 2. Parse the original first line
                line_to_parse = original_first_line.strip()

                if not line_to_parse or line_to_parse.startswith("[Lỗi đọc"):
                    existing_title = "[Lỗi đọc dòng đầu gốc]"; processed = True
                else:
                    line_lower = line_to_parse.lower()

                    # --- ƯU TIÊN 1: TÌM DẤU PHÂN CÁCH RÕ RÀNG ---
                    for sep in separators_to_try:
                        parts = line_to_parse.split(sep, 1)
                        if len(parts) == 2: # Tìm thấy dấu tách
                            prefix_part = parts[0].strip()
                            potential_title = parts[1].strip()

                            # Kiểm tra đơn giản: Nếu phần trước dấu tách có vẻ là chỉ báo chương
                            # (chứa từ khóa HOẶC chỉ chứa số/khoảng trắng/vài ký tự)
                            # VÀ phần sau không rỗng
                            is_prefix_likely = False
                            prefix_lower_check = prefix_part.lower()
                            if any(keyword in prefix_lower_check for keyword in CHAPTER_KEYWORDS):
                                is_prefix_likely = True
                            elif re.fullmatch(r'[\s\d\w]{1,15}', prefix_part): # Ngắn và chứa chữ/số/khoảng trắng
                                 is_prefix_likely = True

                            if is_prefix_likely and potential_title:
                                existing_title = potential_title
                                processed = True
                                logger.debug(f"Fix ({filename}): Priority Separator '{sep}'. Title: '{existing_title}'")
                                break # Dừng lại khi tìm thấy dấu tách hợp lệ

                    # --- ƯU TIÊN 2: XỬ LÝ CÁC KIỂU ĐẶC BIỆT (NẾU CHƯA TÌM THẤY DẤU TÁCH) ---
                    if not processed:
                        # Kiểu 1: Bắt đầu bằng "Đệ", chứa "chương"
                        if line_lower.startswith("đệ"):
                            chuong_index = line_lower.find("chương")
                            if chuong_index != -1:
                                end_of_chuong_word = chuong_index + len("chương")
                                title_part = line_to_parse[end_of_chuong_word:].lstrip(' \t:.,-')
                                if title_part: existing_title = title_part; processed = True; logger.debug(f"Fix ({filename}): Type 1 match. Title: '{existing_title}'")

                        # Kiểu 2: Bắt đầu bằng "Chương/Quyển", kết thúc số bằng chữ
                        if not processed and any(line_lower.startswith(kw) for kw in ["chương ", "quyển "]): # Thêm khoảng trắng để chắc chắn
                            words = line_to_parse.split(); last_num_word_index = -1
                            start_check_index = 1
                            if len(words) > 1 and words[1].lower() in BUFFER_WORDS: start_check_index = 2
                            for k in range(start_check_index, len(words)):
                                word_clean = words[k].lower().rstrip(':.,-')
                                if word_clean in VIETNAMESE_NUMBER_WORDS or word_clean.isdigit(): last_num_word_index = k
                                else: break # Dừng khi gặp từ không phải số
                            if last_num_word_index != -1 and last_num_word_index + 1 < len(words):
                                existing_title = " ".join(words[last_num_word_index + 1:]).strip()
                                processed = True; logger.debug(f"Fix ({filename}): Type 2 match. Title: '{existing_title}'")

                    # --- FALLBACK CUỐI CÙNG (NẾU VẪN CHƯA XỬ LÝ) ---
                    if not processed:
                        existing_title = line_to_parse.lstrip('*# \t') # Lấy cả dòng
                        logger.debug(f"Fix ({filename}): Fallback, using cleaned line: '{existing_title}'")

                    # Đảm bảo không rỗng
                    if not existing_title: existing_title = "[Không có tiêu đề]"

                # 3. Construct the new first line
                new_first_line = f"Chương {extracted_number_file}: {existing_title}"

                # 4. Add to preview only if changed
                norm_orig = ' '.join(original_first_line.split()); norm_new = ' '.join(new_first_line.split())
                if norm_new != norm_orig:
                    preview_items.append({'path': path, 'filename': filename, 'original_line': original_first_line, 'new_line': new_first_line, 'iid': iid})
                else: skipped_count += 1

            except Exception as e:
                logger.error(f"Error calc fix preview {filename}: {e}", exc_info=True)
                errors_calculating += 1

        # --- Show Preview Window ---
        if errors_calculating > 0: messagebox.showwarning("Lỗi Tính Toán", f"Lỗi tính toán xem trước {errors_calculating} file.", parent=self)
        if not preview_items: messagebox.showinfo("Không cần sửa", f"Không file nào cần sửa trong {total_selected} file (bỏ qua {skipped_count}).", parent=self); return
        final_preview_data = copy.deepcopy(preview_items); PreviewWindow(self, "Xem trước sửa lỗi số chương", final_preview_data, len(preview_items), self.trigger_apply_fixes)

    def trigger_apply_fixes(self, data_to_apply):
        logger.info(f"Applying fixes {len(data_to_apply)} files."); msg = lambda p, e, s: f"Đã sửa {p} file.\nLỗi: {e} file."
        self._run_file_operation_in_thread(data_to_apply, self._process_apply_fix, "Đang áp dụng sửa lỗi...", msg)

    def show_insert_preview(self):
        logger.debug("Show insert preview..."); selected_data = self._get_selected_data(); total_selected = len(selected_data)
        if not selected_data: messagebox.showwarning("Chưa chọn", "Chọn ít nhất một file.", parent=self); return
        preview_items = []; errors_calculating = 0; skipped_already_formatted = 0; chapter_pattern = re.compile(r'^\s*[Cc]hương\s+\d+\s*[:]?.*', re.IGNORECASE)
        for item_data in selected_data:
            path = item_data['path']; filename = item_data['orig_filename']; original_first_line = item_data['orig_line']; iid = item_data['iid']; inserted_line = None
            try:
                if chapter_pattern.match(original_first_line): skipped_already_formatted += 1; continue
                match_num_c = re.search(r'[Cc]([0-9]+)', filename); match_num_chuong = re.search(r'[Cc]hương\s*([0-9]+)', filename); extracted_number = None
                if match_num_c: extracted_number = int(match_num_c.group(1))
                elif match_num_chuong: extracted_number = int(match_num_chuong.group(1))
                if extracted_number is None: logger.warning(f"Skip insert {filename}: no num."); errors_calculating += 1; continue
                inserted_line = f"Chương {extracted_number}: "
                preview_items.append({'path': path, 'filename': filename, 'original_line': original_first_line, 'inserted_line': inserted_line, 'iid': iid})
            except ValueError: logger.warning(f"Error calc insert {filename}: invalid num."); errors_calculating += 1
            except Exception as e: logger.error(f"Error calc insert {filename}: {e}", exc_info=True); errors_calculating += 1
        if skipped_already_formatted > 0: messagebox.showinfo("Thông tin", f"{skipped_already_formatted} file đã có định dạng.", parent=self)
        if errors_calculating > 0: messagebox.showwarning("Lỗi Tính Toán", f"Lỗi tính toán {errors_calculating} file (không số?).", parent=self)
        if not preview_items: messagebox.showinfo("Không cần chèn", f"Không file nào cần chèn.", parent=self); return
        final_preview_data = copy.deepcopy(preview_items); PreviewWindow(self, "Xem trước chèn số chương", final_preview_data, len(preview_items), self.trigger_apply_inserts, apply_button_text="✅ Chèn số chương")

    def trigger_apply_inserts(self, data_to_apply):
        logger.info(f"Applying inserts {len(data_to_apply)} files."); msg = lambda p, e, s: f"Đã chèn {p} file.\nBỏ qua: {s} file.\nLỗi: {e} file."
        items_to_process = [{'path': item['path'], 'orig_filename': item['filename'], 'iid': item['iid']} for item in data_to_apply]
        self._run_file_operation_in_thread(items_to_process, self._process_insert_number, "Đang chèn số chương...", msg)

    def _trigger_main_reader_update(self, changed_paths_set):
        if self.reader_window_ref and self.reader_window_ref.winfo_exists(): self.reader_window_ref.check_and_update_main_reader(changed_paths_set)
        else: logger.debug("Reader ref gone.")

    def _on_double_click(self, event):
        try:
            item_id_str = self.tree.identify_row(event.y);
            if not item_id_str: return
            iid_int = int(item_id_str); selected_item_data = next((item for item in self.all_items_data if item.get('iid') == iid_int), None)
            if selected_item_data and 'path' in selected_item_data:
                file_path_to_load = selected_item_data['path']; logger.info(f"Double-click iid={iid_int}, path={file_path_to_load}")
                if self.reader_window_ref and self.reader_window_ref.winfo_exists(): self.reader_window_ref.load_specific_file(file_path_to_load)
                else: logger.warning("Reader ref invalid."); messagebox.showwarning("Lỗi", "Không tìm thấy cửa sổ đọc.", parent=self)
            else: logger.warning(f"No data/path double-click iid={iid_int}.")
        except ValueError: logger.error(f"Invalid iid '{item_id_str}'.")
        except Exception as e: logger.error(f"Error double-click: {e}", exc_info=True); messagebox.showerror("Lỗi", f"Lỗi double-click:\n{e}", parent=self)

# ==============================================================
# LỚP CỬA SỔ ĐỌC CHÍNH (ReadWindow)
# ==============================================================
class ReadWindow(tk.Toplevel):
    def __init__(self, parent, selected_source_dir, initial_font_family, initial_font_size):
        super().__init__(master=parent); self.master = parent; self.selected_source_dir = Path(selected_source_dir); self.folder_path = self.selected_source_dir / "translated"
        self.title("📖 Đọc chương đã dịch"); self.geometry("1600x800"); self.minsize(1000, 600)
        self.file_list = []; self.current_index = -1
        self.font_family = tk.StringVar(value=initial_font_family); self.font_size = tk.IntVar(value=initial_font_size); self.only_first_line = tk.BooleanVar(value=False)
        self.duplicate_removal_queue = queue.Queue()
        try:
            if not self.folder_path.is_dir(): raise FileNotFoundError(f"Thư mục dịch không tồn tại: {self.folder_path}")
            self._reload_file_list()
            if not self.file_list: logger.warning(f"Không file .txt trong: {self.folder_path}")
        except Exception as e: logger.error(f"ReadWindow init error: {e}", exc_info=True); messagebox.showerror("Lỗi", f"Lỗi mở thư mục đọc:\n{e}", parent=self); self.after(10, self.destroy); return
        self.setup_ui()
        if self.file_list:
             self.current_index = 0
             if hasattr(self, 'chapter_dropdown'): self.chapter_dropdown["values"] = self.file_list; self.chapter_dropdown.current(self.current_index)
             else: logger.error("chapter_dropdown missing after setup_ui")
             self.update_texts()
        else:
             if hasattr(self, 'chapter_dropdown'): self.chapter_dropdown["values"] = []; self.chapter_dropdown.set("(Không có file)")
             self.clear_text_areas(); self.title("📖 Đọc chương đã dịch (Thư mục rỗng)")
        self.bind("<Control-s>", lambda e: self.save_changes()); self.font_family.trace_add("write", lambda *a: self.update_font()); self.font_size.trace_add("write", lambda *a: self.update_font())
        self.protocol("WM_DELETE_WINDOW", self.on_reader_closing)

    def setup_ui(self):
        top_frame = ttk.Frame(self); top_frame.pack(fill="x", pady=5, padx=5)
        ttk.Label(top_frame, text="Chọn chương:").pack(side="left")
        try: self.chapter_dropdown = ttk.Combobox(top_frame, state="readonly", width=40); self.chapter_dropdown.pack(side="left", padx=5); self.chapter_dropdown.bind("<<ComboboxSelected>>", self.select_chapter)
        except Exception as e: logger.critical(f"Failed create chapter_dropdown: {e}", exc_info=True); messagebox.showerror("Lỗi Giao Diện", f"Lỗi tạo combobox chương:\n{e}", parent=self)
        ttk.Button(top_frame, text="⏪ Trước", command=self.prev_chapter).pack(side="left", padx=5); ttk.Button(top_frame, text="⏩ Sau", command=self.next_chapter).pack(side="left", padx=5)
        ttk.Label(top_frame, text="Font:").pack(side="left", padx=(20, 5));
        try: font_families = sorted([f for f in font.families(self) if not f.startswith('@')])
        except: font_families = ["Consolas", "Arial", "Times New Roman", "Courier New", "Segoe UI", "Tahoma"]
        ttk.Combobox(top_frame, textvariable=self.font_family, values=font_families, state="readonly", width=15).pack(side="left"); ttk.Label(top_frame, text="Cỡ:").pack(side="left", padx=5); ttk.Spinbox(top_frame, from_=8, to=32, textvariable=self.font_size, width=5, command=self.update_font).pack(side="left")
        button_frame_right = ttk.Frame(top_frame); button_frame_right.pack(side="right")
        ttk.Button(button_frame_right, text="🚫 Rà soát dòng lặp", command=self.show_duplicate_line_preview).pack(side="right", padx=5) # Nút mới
        ttk.Button(button_frame_right, text="📄 List dòng đầu", command=self.open_first_lines_window).pack(side="right", padx=5)
        ttk.Button(button_frame_right, text="💾 Lưu (Ctrl+S)", command=self.save_changes).pack(side="right", padx=5)
        find_frame = ttk.Frame(self); find_frame.pack(fill="x", padx=10, pady=5); ttk.Label(find_frame, text="Tìm:").pack(side="left"); self.entry_find = ttk.Entry(find_frame, width=25); self.entry_find.pack(side="left", padx=5); ttk.Label(find_frame, text="Thay bằng:").pack(side="left"); self.entry_replace = ttk.Entry(find_frame, width=25); self.entry_replace.pack(side="left", padx=5); ttk.Checkbutton(find_frame, text="Chỉ thay dòng đầu", variable=self.only_first_line).pack(side="left", padx=5); ttk.Button(find_frame, text="🔁 Thay thế toàn bộ", command=self.replace_all).pack(side="left", padx=10)
        content_frame = ttk.PanedWindow(self, orient=tk.HORIZONTAL); content_frame.pack(fill="both", expand=True, padx=5, pady=(0, 5))
        frame1 = ttk.Frame(content_frame, relief="sunken", borderwidth=1); content_frame.add(frame1, weight=1); scroll1 = ttk.Scrollbar(frame1, orient="vertical"); self.text1 = tk.Text(frame1, wrap="word", undo=True, yscrollcommand=scroll1.set, font=(self.font_family.get(), self.font_size.get())); scroll1.config(command=self.text1.yview); scroll1.pack(side="right", fill="y"); self.text1.pack(side="left", fill="both", expand=True); self._apply_text_theme(self.text1)
        frame2 = ttk.Frame(content_frame, relief="sunken", borderwidth=1); content_frame.add(frame2, weight=1); scroll2 = ttk.Scrollbar(frame2, orient="vertical"); self.text2 = tk.Text(frame2, wrap="word", undo=True, yscrollcommand=scroll2.set, font=(self.font_family.get(), self.font_size.get())); scroll2.config(command=self.text2.yview); scroll2.pack(side="right", fill="y"); self.text2.pack(side="left", fill="both", expand=True); self._apply_text_theme(self.text2)

    def _apply_text_theme(self, text_widget):
         try: style = self.master.style; fg = style.colors.get("fg", "black"); bg = style.colors.get("inputbg", "white"); select_bg = style.colors.get("selectbg", "#0078D7"); select_fg = style.colors.get("selectfg", "white"); insert_bg = fg; text_widget.config(fg=fg, bg=bg, selectbackground=select_bg, selectforeground=select_fg, insertbackground=insert_bg)
         except Exception as e: logger.warning(f"Could not apply theme colors to text: {e}")

    def open_first_lines_window(self): FirstLinesWindow(self.master, self.selected_source_dir, self)
    def update_font(self, *args):
        try: font_tuple = (self.font_family.get(), self.font_size.get()); self.text1.config(font=font_tuple); self.text2.config(font=font_tuple); logger.debug(f"Reader font update: {font_tuple}")
        except tk.TclError as e: logger.error(f"Error set reader font: {e}.")
        except Exception as e: logger.error(f"Unexpected error update font: {e}", exc_info=True)

    def _reload_file_list(self):
        try:
            self.file_list = sorted([f.name for f in self.folder_path.glob("*.txt") if f.is_file()])
            logger.info(f"Reload list: {len(self.file_list)} files in {self.folder_path}")
            if hasattr(self, 'chapter_dropdown'):
                self.chapter_dropdown["values"] = self.file_list
            else: logger.warning("Cannot update chapter_dropdown reload."); return
            if self.file_list:
                if self.current_index >= len(self.file_list) or self.current_index < 0: self.current_index = 0
                self.chapter_dropdown.current(self.current_index)
            else:
                self.current_index = -1
                self.chapter_dropdown.set("")
            if not self.file_list:
                self.clear_text_areas()
                self.title("📖 Đọc chương (Không có file)")
        except Exception as e:
            logger.error(f"Error reload list {self.folder_path}: {e}", exc_info=True)
            messagebox.showerror("Lỗi", f"Lỗi tải lại list:\n{e}", parent=self)
            self.file_list = []
            self.current_index = -1
            if hasattr(self, 'chapter_dropdown'):
                self.chapter_dropdown["values"] = []
                self.chapter_dropdown.set("")
            self.clear_text_areas(); self.title("📖 Đọc chương (Lỗi)")

    def update_texts(self):
        if not hasattr(self, 'text1') or not hasattr(self, 'text2'): logger.error("Cannot update texts: widgets missing."); return
        logger.debug(f"Update texts idx {self.current_index}"); self.update_font()
        self.text1.config(state=tk.NORMAL); self.text2.config(state=tk.NORMAL); self.text1.delete("1.0", "end"); self.text2.delete("1.0", "end")
        content1 = self.read_file(self.current_index); content2 = self.read_file(self.current_index + 1)
        if content1 is not None: self.text1.insert("1.0", content1); self.text1.edit_reset(); self.text1.edit_modified(False)
        else: fname = self.file_list[self.current_index] if 0<=self.current_index<len(self.file_list) else 'N/A'; self.text1.insert("1.0", f"[Lỗi đọc: {fname}]"); logger.warning(f"Fail read idx {self.current_index} ({fname})")
        if content2 is not None: self.text2.insert("1.0", content2); self.text2.edit_reset(); self.text2.edit_modified(False)
        else:
            if 0 <= self.current_index + 1 < len(self.file_list): fname = self.file_list[self.current_index+1]; self.text2.insert("1.0", f"[Lỗi đọc: {fname}]"); logger.warning(f"Fail read idx {self.current_index + 1} ({fname})")
            else: self.text2.insert("1.0", "[Hết chương]")
        self.text1.mark_set(tk.INSERT, "1.0"); self.text1.see("1.0"); self.text2.mark_set(tk.INSERT, "1.0"); self.text2.see("1.0")
        if 0 <= self.current_index < len(self.file_list): self.title(f"📖 Đọc: {self.file_list[self.current_index]}")
        else: self.title("📖 Đọc chương")
        self.update_idletasks()

    def read_file(self, index):
        if 0 <= index < len(self.file_list):
            path = self.folder_path / self.file_list[index]
            if not path.is_file(): logger.warning(f"Not file: {path}"); return None
            try:
                encs=['utf-8', 'cp1252', 'latin-1']
                for enc in encs:
                    try:
                        return path.read_text(encoding=enc)
                    except UnicodeDecodeError: pass
                logger.error(f"Failed read {path.name} encodings."); return None
            except Exception as e: logger.error(f"Failed read {path.name}: {e}", exc_info=True); return None
        return None

    def select_chapter(self, event=None):
        if not hasattr(self, 'chapter_dropdown'): logger.error("No chapter dropdown."); return
        new_index = self.chapter_dropdown.current()
        if new_index >= 0 and new_index != self.current_index: logger.debug(f"Chapter selected: {new_index}"); self.current_index = new_index; self.update_texts()

    def prev_chapter(self):
        if self.current_index > 0:
           self.current_index -= 1
           if hasattr(self, 'chapter_dropdown'): self.chapter_dropdown.current(self.current_index)
           self.update_texts(); logger.debug(f"Nav prev: {self.current_index}")

    def next_chapter(self):
        if self.current_index < len(self.file_list) - 1:
           self.current_index += 1
           if hasattr(self, 'chapter_dropdown'): self.chapter_dropdown.current(self.current_index)
           self.update_texts(); logger.debug(f"Nav next: {self.current_index}")

    def save_changes(self):
        logger.info("Attempt save..."); saved = []; errors = []
        def _save(idx, content):
            if 0 <= idx < len(self.file_list):
                fname = self.file_list[idx]; pth = self.folder_path / fname
                try: pth.write_text(content, encoding="utf-8"); logger.info(f"Saved: {fname}"); return True, fname
                except Exception as e: logger.error(f"Fail save {fname}: {e}", exc_info=True); messagebox.showerror("Lỗi lưu", f"Lỗi:\n{fname}\n\n{e}", parent=self); return False, fname
            return True, None
        c1 = self.text1.get("1.0", "end-1c"); c2 = self.text2.get("1.0", "end-1c")
        s1, f1 = _save(self.current_index, c1); s2, f2 = _save(self.current_index + 1, c2)
        if f1: (saved if s1 else errors).append(f1)
        if f2: (saved if s2 else errors).append(f2)
        if not errors and saved: messagebox.showinfo("Đã lưu", f"Đã lưu:\n- {', '.join(saved)}", parent=self); self.text1.edit_modified(False); self.text2.edit_modified(False)
        elif errors: logger.warning(f"Errors saving: {errors}")

    def replace_all(self):
        find = self.entry_find.get(); replace = self.entry_replace.get()
        if not find: messagebox.showwarning("Thiếu", "Nhập văn bản tìm.", parent=self); return
        only_first = self.only_first_line.get(); msg = f"Thay TẤT CẢ '{find}' bằng '{replace}' trong {len(self.file_list)} file?"
        if only_first: msg = f"Thay '{find}' bằng '{replace}' CHỈ Ở DÒNG ĐẦU của {len(self.file_list)} file?"
        if not ConfirmationDialog(self, "Xác nhận thay thế", msg).result: logger.info("Replace cancelled."); return
        logger.info(f"Start replace all. Find='{find}', Rep='{replace}', First={only_first}")
        count_rep=0; count_chg=0; changed_paths = set()
        prog_win = tk.Toplevel(self); prog_win.title("Đang thay thế..."); prog_win.geometry("350x120"); prog_win.transient(self); prog_win.grab_set(); prog_win.resizable(False, False); lbl = ttk.Label(prog_win, text="Chuẩn bị..."); lbl.pack(pady=10, padx=10, anchor='w'); bar = ttk.Progressbar(prog_win, length=330, mode='determinate', maximum=len(self.file_list)); bar.pack(pady=5, padx=10); self.update_idletasks(); px=self.winfo_rootx();py=self.winfo_rooty();pw=self.winfo_width();ph=self.winfo_height();dw=prog_win.winfo_width();dh=prog_win.winfo_height();x=px+(pw//2)-(dw//2);y=py+(ph//2)-(dh//2);prog_win.geometry(f'+{x}+{y}');prog_win.update()
        for i, fname in enumerate(self.file_list):
            pth = self.folder_path / fname; lbl.config(text=f"Xử lý: {fname} ({i+1}/{len(self.file_list)})"); bar['value'] = i + 1; prog_win.update_idletasks()
            try:
                orig_c = None; encs = ['utf-8','cp1252','latin-1']; read_ok=False
                for enc in encs:
                    try:
                        orig_c=pth.read_text(encoding=enc)
                        read_ok=True
                        break
                    except UnicodeDecodeError: pass
                if not read_ok or orig_c is None: logger.warning(f"Read fail replace: {fname}"); continue
                new_c = orig_c; rep_count = 0
                if only_first:
                    lines = orig_c.splitlines()
                    if lines: orig_l = lines[0]; lines[0] = lines[0].replace(find, replace)
                    if lines[0] != orig_l: rep_count = orig_l.count(find); new_c = "\n".join(lines)
                else:
                    rep_count = orig_c.count(find)
                    if rep_count > 0: new_c = orig_c.replace(find, replace)
                if new_c != orig_c: pth.write_text(new_c, encoding="utf-8"); count_rep += rep_count; count_chg += 1; changed_paths.add(pth); logger.debug(f"Replaced {rep_count} in {fname}")
            except FileNotFoundError: logger.warning(f"Not found replace: {fname}"); continue
            except Exception as e: logger.error(f"Error replace {fname}: {e}", exc_info=True)
        prog_win.destroy(); messagebox.showinfo("Hoàn tất", f"Đã thay thế {count_rep} lần trong {count_chg} file.", parent=self)
        self.check_and_update_main_reader(changed_paths)

    def check_and_update_main_reader(self, changed_paths_set):
        update = False; cur_path = None; nxt_path = None
        if 0 <= self.current_index < len(self.file_list): cur_path = self.folder_path / self.file_list[self.current_index]
        if 0 <= self.current_index + 1 < len(self.file_list): nxt_path = self.folder_path / self.file_list[self.current_index + 1]
        if cur_path and cur_path in changed_paths_set: update = True; logger.info(f"Reader left changed ({cur_path.name}), reload.")
        if not update and nxt_path and nxt_path in changed_paths_set: update = True; logger.info(f"Reader right changed ({nxt_path.name}), reload.")
        if update: self.after(50, self.update_texts)

    def update_source_directory(self, new_source_dir):
        new_path = Path(new_source_dir)
        if new_path != self.selected_source_dir:
            logger.info(f"Reader update src dir: {new_path}")
            self.selected_source_dir = new_path
            self.folder_path = self.selected_source_dir / "translated"; self._reload_file_list()
            if self.file_list:
                self.current_index = 0;
                if hasattr(self, 'chapter_dropdown'):
                    self.chapter_dropdown.current(0)
                self.update_texts()
            else:
                self.current_index = -1
                if hasattr(self, 'chapter_dropdown'):
                    self.chapter_dropdown.set("")
                self.clear_text_areas(); self.title("📖 Đọc chương (Không file)")
        else: logger.debug("Reader src dir unchanged.")

    def clear_text_areas(self):
        if hasattr(self, 'text1') and self.text1: self.text1.config(state=tk.NORMAL); self.text1.delete('1.0', tk.END); self.text1.edit_modified(False)
        if hasattr(self, 'text2') and self.text2: self.text2.config(state=tk.NORMAL); self.text2.delete('1.0', tk.END); self.text2.edit_modified(False)

    def load_specific_file(self, file_path_to_load):
        if not file_path_to_load or not hasattr(self, 'file_list'): logger.warning("Cannot load specific: invalid path/list."); return
        fname = Path(file_path_to_load).name
        try:
            target_idx = self.file_list.index(fname)
            if 0 <= target_idx < len(self.file_list):
                logger.info(f"Load specific: '{fname}' idx {target_idx}")
                self.current_index = target_idx
                if hasattr(self, 'chapter_dropdown') and self.chapter_dropdown.winfo_exists():
                    self.chapter_dropdown.current(self.current_index)
                self.update_texts()
                self.lift(); self.focus_force()
            else: logger.warning(f"Idx {target_idx} out of bounds."); messagebox.showwarning("Lỗi", f"Không tìm thấy '{fname}'.", parent=self)
        except ValueError: logger.error(f"File '{fname}' not in list."); messagebox.showerror("Lỗi", f"File '{fname}' không có trong list.", parent=self)
        except Exception as e: logger.error(f"Error load specific '{fname}': {e}", exc_info=True); messagebox.showerror("Lỗi", f"Lỗi tải file:\n{e}", parent=self)

    # --- HÀM MỚI: HIỂN THỊ PREVIEW XÓA LẶP ---
    def show_duplicate_line_preview(self):
        if not self.file_list: messagebox.showwarning("Thông báo", "Không có file để rà soát.", parent=self); return
        logger.info(f"Scanning duplicates in: {self.folder_path}"); self.log_to_reader("INFO: Bắt đầu rà soát dòng lặp...")
        preview_items = []; files_scanned = 0; potential_duplicates_found = 0; lines_to_check = 5
        # Progress Window
        prog_win = tk.Toplevel(self); prog_win.title("Đang rà soát..."); prog_win.geometry("350x100"); prog_win.transient(self); prog_win.grab_set(); prog_win.resizable(False, False); lbl = ttk.Label(prog_win, text="Quét file...", wraplength=330); lbl.pack(pady=10, padx=10, fill='x'); bar = ttk.Progressbar(prog_win, length=330, mode='determinate', maximum=len(self.file_list)); bar.pack(pady=5, padx=10, fill='x'); self.update_idletasks(); px=self.winfo_rootx();py=self.winfo_rooty();pw=self.winfo_width();ph=self.winfo_height();dw=prog_win.winfo_width();dh=prog_win.winfo_height();x=px+(pw//2)-(dw//2);y=py+(ph//2)-(dh//2);prog_win.geometry(f'+{x}+{y}');prog_win.update()
        # Scan loop
        for i, filename in enumerate(self.file_list):
            lbl.config(text=f"Kiểm tra: {filename} ({i+1}/{len(self.file_list)})"); bar['value'] = i + 1; prog_win.update_idletasks()
            fpath = self.folder_path / filename
            try:
                lines = []; fcontent = None; encs = ['utf-8','cp1252','latin-1']; read_ok=False
                for enc in encs:
                    try:
                        with fpath.open('r', encoding=enc) as f: [lines.append(f.readline().strip()) for _ in range(lines_to_check) if f.readable()]
                        fcontent = fpath.read_text(encoding=enc); read_ok = True; break
                    except (UnicodeDecodeError, FileNotFoundError): continue
                if not read_ok: logger.warning(f"Read fail dup check: {filename}"); continue
                files_scanned += 1; dup_line_remove = None; dup_idx = -1
                if len(lines) >= 2:
                    l1 = lines[0]; t1 = l1.split(':', 1)[-1].strip()
                    if t1:
                        if len(lines) >= 2:
                            l2 = lines[1]
                            t2 = l2.split(':', 1)[-1].strip()
                            if t1 == t2: dup_line_remove = l2
                            dup_idx = 1
                            logger.debug(f"Dup line 2 {filename}: '{l1}' vs '{l2}'")
                        if dup_line_remove is None and len(lines) >= 3:
                            l3 = lines[2]
                            t3 = l3.split(':', 1)[-1].strip()
                            if t1 == t3: dup_line_remove = l3; dup_idx = 2; logger.debug(f"Dup line 3 {filename}: '{l1}' vs '{l3}'")
                if dup_line_remove is not None:
                    potential_duplicates_found += 1
                    preview_items.append({'path': fpath, 'filename': filename, 'original_line': l1, 'proposed': dup_line_remove, 'line_index_to_remove': dup_idx, 'full_content': fcontent})
            except Exception as e: logger.error(f"Error scan dup {filename}: {e}", exc_info=True)
        prog_win.destroy()
        self.log_to_reader(f"INFO: Rà soát xong {files_scanned} file. {potential_duplicates_found} lặp tiềm năng.")
        if not preview_items: messagebox.showinfo("Hoàn tất", "Không tìm thấy dòng lặp.", parent=self); return
        DuplicatePreviewWindow(self, "Xem trước xóa dòng lặp", preview_items, self.trigger_apply_duplicate_removal)

    # --- HÀM MỚI: TRIGGER XÓA SAU PREVIEW ---
    def trigger_apply_duplicate_removal(self, items_to_fix):
        if not items_to_fix: logger.info("No items for duplicate removal."); return
        logger.info(f"Applying duplicate removal {len(items_to_fix)} files.")
        prog_win = tk.Toplevel(self); prog_win.title("Đang xóa dòng lặp..."); prog_win.geometry("400x130"); prog_win.transient(self); prog_win.grab_set(); prog_win.resizable(False, False); lbl = ttk.Label(prog_win, text="Chuẩn bị...", wraplength=380); lbl.pack(pady=10, padx=10, anchor='w', fill='x'); bar = ttk.Progressbar(prog_win, length=380, mode='determinate', maximum=len(items_to_fix)); bar.pack(pady=5, padx=10, fill='x'); self.update_idletasks(); px=self.winfo_rootx();py=self.winfo_rooty();pw=self.winfo_width();ph=self.winfo_height();dw=prog_win.winfo_width();dh=prog_win.winfo_height();x=px+(pw//2)-(dw//2);y=py+(ph//2)-(dh//2);prog_win.geometry(f'+{x}+{y}');prog_win.update()
        worker_thread = threading.Thread(target=self._run_apply_duplicates_worker, args=(items_to_fix,), daemon=True); worker_thread.start()
        self.after(100, lambda: self._check_duplicate_removal_queue(prog_win, lbl, bar))

    # --- HÀM MỚI: WORKER XÓA ---
    def _run_apply_duplicates_worker(self, items_to_fix):
        """Worker thread to perform the actual file modifications."""
        fixed_count = 0
        error_count = 0
        changed_paths = set()

        for i, item_data in enumerate(items_to_fix):
            path = item_data.get('path')
            filename = item_data.get('filename', 'N/A')
            line_index_to_remove = item_data.get('line_index_to_remove', -1)
            original_full_content = item_data.get('full_content')

            # Validate data before proceeding
            if not path or line_index_to_remove == -1 or original_full_content is None:
                logger.error(f"Invalid data received for fixing duplicates in {filename}. Skipping.")
                error_count += 1
                self.duplicate_removal_queue.put({'type': 'progress', 'value': i + 1})
                continue

            self.duplicate_removal_queue.put({'type': 'status', 'text': f"Đang sửa: {filename} ({i+1}/{len(items_to_fix)})"})

            try:
                all_lines = original_full_content.splitlines()

                if len(all_lines) <= line_index_to_remove:
                    logger.warning(f"File {filename} changed since scan? Line index {line_index_to_remove} invalid for length {len(all_lines)}.")
                    error_count += 1
                    self.duplicate_removal_queue.put({'type': 'progress', 'value': i + 1})
                    continue

                new_content_lines = []
                # 1. Giữ dòng đầu tiên (index 0)
                if len(all_lines) > 0:
                    new_content_lines.append(all_lines[0])
                else:
                    # Trường hợp cực kỳ hiếm: file trống sau khi quét?
                    logger.warning(f"File {filename} seems empty after reading full content. Skipping fix.")
                    error_count +=1
                    self.duplicate_removal_queue.put({'type': 'progress', 'value': i + 1})
                    continue

                # --- Logic thêm dòng trống có điều kiện ---
                # 2. Xác định index của dòng nội dung thực sự bắt đầu (sau dòng bị xóa)
                start_index_for_rest = line_index_to_remove + 1

                # 3. Kiểm tra xem có cần thêm dòng trống không
                add_blank_line = True
                if start_index_for_rest < len(all_lines):
                    # Nếu dòng ngay sau dòng bị xóa LÀ dòng trống, thì KHÔNG cần thêm nữa
                    if not all_lines[start_index_for_rest].strip():
                        add_blank_line = False
                        logger.debug(f"Skipping adding blank line for {filename}, already exists at index {start_index_for_rest}")

                if add_blank_line:
                    new_content_lines.append("") # Thêm dòng trống
                    logger.debug(f"Adding blank line after header for {filename}")
                # -----------------------------------------

                # 4. Thêm phần còn lại của nội dung
                if start_index_for_rest < len(all_lines):
                    new_content_lines.extend(all_lines[start_index_for_rest:])

                new_content = "\n".join(new_content_lines)

                # Ghi lại file (Chỉ ghi nếu nội dung thay đổi - phòng trường hợp hy hữu)
                if new_content != original_full_content:
                    try:
                        path.write_text(new_content, encoding='utf-8')
                        fixed_count += 1
                        changed_paths.add(path)
                        logger.info(f"Fixed duplicate line in {filename}")
                    except Exception as write_e:
                        logger.error(f"Error writing fixed content to {filename}: {write_e}", exc_info=True)
                        error_count += 1
                else:
                     logger.warning(f"Content unchanged after applying fix logic for {filename}. Skipping write.")
                     # Không tăng fixed_count nếu không ghi

            except Exception as e:
                logger.error(f"Error applying duplicate removal for {filename}: {e}", exc_info=True)
                error_count += 1

            self.duplicate_removal_queue.put({'type': 'progress', 'value': i + 1})
            # time.sleep(0.01) # Optional small delay

        self.duplicate_removal_queue.put({
            'type': 'completion',
            'fixed': fixed_count,
            'errors': error_count,
            'skipped': 0, # Skipped không áp dụng ở bước này
            'changed_paths': changed_paths
        })
        logger.info("Apply duplicate removal worker finished.")

    # --- HÀM MỚI/CŨ: KIỂM TRA QUEUE XÓA LẶP ---
    def _check_duplicate_removal_queue(self, progress_win, status_label, progress_bar):
        try:
            while True:
                msg = self.duplicate_removal_queue.get_nowait()
                if not progress_win.winfo_exists(): return
                if msg['type'] == 'status': status_label.config(text=msg['text'])
                elif msg['type'] == 'progress': progress_bar['value'] = msg['value']
                elif msg['type'] == 'completion':
                    progress_win.destroy()
                    fixed = msg.get('fixed', 0); errors = msg.get('errors', 0); skipped = msg.get('skipped', 0)
                    res_msg = f"Hoàn tất xóa!\n\nĐã sửa: {fixed} file\nLỗi: {errors} file."
                    if skipped > 0: res_msg += f"\nBỏ qua (quét): {skipped} file." # Show skipped from scan phase if applicable
                    messagebox.showinfo("Xóa dòng lặp hoàn tất", res_msg, parent=self)
                    self.log_to_reader(f"INFO: {res_msg.replace('!','').replace('\n\n', '. ')}")
                    self.check_and_update_main_reader(msg['changed_paths'])
                    return
            # progress_win.update_idletasks() # Can remove if causing lag
        except queue.Empty:
            if progress_win.winfo_exists(): self.after(100, lambda: self._check_duplicate_removal_queue(progress_win, status_label, progress_bar))
        except Exception as e: logger.error(f"Error check dup removal queue: {e}", exc_info=True);
        if progress_win.winfo_exists(): progress_win.destroy()

    def log_to_reader(self, message, level="INFO"):
        if hasattr(self, 'text1') and self.text1.winfo_exists():
            timestamp = time.strftime("[%H:%M:%S]"); full_message = f"{timestamp} [{level}] {message}\n"
            self.after(0, self._insert_log_message, full_message)
    def _insert_log_message(self, message):
        try: self.text1.config(state=tk.NORMAL); self.text1.insert("1.0", message); self.text1.config(state=tk.DISABLED)
        except tk.TclError as e: logger.warning(f"Could not log to reader: {e}")

    def on_reader_closing(self):
        logger.info("Reader closing.");
        if self.master and hasattr(self.master, 'settings'): self.master.settings["reader_font_family"] = self.font_family.get(); self.master.settings["reader_font_size"] = self.font_size.get()
        self.destroy(); logger.info("Reader destroyed.")